# -*- coding: utf-8 -*-

from . import competance
from . import departement_service
from . import employee
from . import evaluation_fournisseurs
from . import objectifqualite
from . import audits
from . import reclamation
